# Parallels Snapshotter

Snapshots of parallels per command line; quick create by template


## Installation

```bash
pip3 install prlsnapshotter
```